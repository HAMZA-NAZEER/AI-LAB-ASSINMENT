"""Traceable lexical or sentence-embedding retrieval for the Lab 6 exercises."""

from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer


class Retriever:
    def __init__(self, records: list[dict[str, Any]], backend: str = "tfidf", model=None):
        if not records or any(not str(row.get("text", "")).strip() for row in records):
            raise ValueError("Provide nonempty records with nonempty text")
        if backend not in {"tfidf", "embedding"}:
            raise ValueError("Use backend='tfidf' or backend='embedding'")
        self.records = records
        self.backend = backend
        texts = [row["text"] for row in records]
        if backend == "tfidf":
            self.vectorizer = TfidfVectorizer()
            self.matrix = self.vectorizer.fit_transform(texts)
        else:
            if model is None:
                from sentence_transformers import SentenceTransformer
                model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2", device="cpu")
            self.model = model
            self.check_length(texts)
            self.matrix = self.model.encode(texts, normalize_embeddings=True, convert_to_numpy=True)

    def check_length(self, texts: list[str]) -> None:
        for text in texts:
            length = len(self.model.tokenizer(text, truncation=False)["input_ids"])
            if length > self.model.max_seq_length:
                raise ValueError(
                    f"Input has {length} model tokens; limit is {self.model.max_seq_length}. Rechunk it."
                )

    def search(self, query: str, k: int = 3, filters: dict[str, Any] | None = None):
        if not query.strip() or k <= 0:
            return []
        if self.backend == "tfidf":
            vector = self.vectorizer.transform([query])
            if vector.nnz == 0:
                return []
            scores = (vector @ self.matrix.T).toarray()[0]
        else:
            self.check_length([query])
            q = self.model.encode([query], normalize_embeddings=True, convert_to_numpy=True)[0]
            scores = self.matrix @ q
        allowed = [
            i for i, row in enumerate(self.records)
            if all(row.get(key) == value for key, value in (filters or {}).items())
        ]
        ranked = sorted(allowed, key=lambda i: (-float(scores[i]), i))
        return [(self.records[i], float(scores[i])) for i in ranked[:k]]


def show_hits(hits) -> None:
    if not hits:
        print("No matching records.")
        return
    for row, score in hits:
        print(row.get("id", "(no id)"), f"score={score:.3f}")
        print(row["text"])


if __name__ == "__main__":
    samples = [
        {"id": "faq:password", "text": "Reset a forgotten password using the recovery link."},
        {"id": "faq:submit", "text": "Submit assignments through the learning portal."},
    ]
    print("TF-IDF retrieval helper ready:")
    show_hits(Retriever(samples).search("recover my password", k=1))
