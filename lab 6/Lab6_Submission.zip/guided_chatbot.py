"""Conservative FAQ retrieval: exact questions answer; other matches are suggestions."""

from __future__ import annotations

import argparse

from lab6_search import Retriever

FAQ = [
    {"id": "faq:password", "question": "How do I reset my password?", "answer": "Use the recovery link on the login page.", "source": "it_help.txt"},
    {"id": "faq:submit", "question": "Where do I submit my assignment?", "answer": "Use the assignment upload page in the learning portal.", "source": "assessment.txt"},
    {"id": "faq:late", "question": "Can illness justify a late submission?", "answer": "Request an extension with medical evidence before the deadline.", "source": "handbook.txt"},
]


def build_bot(backend="tfidf", model=None):
    records = [dict(row, text=row["question"] + " " + row["answer"]) for row in FAQ]
    return Retriever(records, backend, model=model)


def reply(engine, query):
    if not query.strip():
        return "Please enter a question."
    for row in FAQ:
        if query.strip().casefold() == row["question"].casefold():
            return f"{row['answer']} [source: {row['source']}]"
    hits = engine.search(query, k=3)
    if not hits:
        return "No matching FAQ. Please contact the help desk."
    lines = ["Possible matches; confirm a canonical question before relying on an answer:"]
    for row, score in hits:
        lines.append(f"{row['question']} (similarity {score:.3f})")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--backend", choices=["tfidf", "embedding"], default="tfidf")
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()
    engine = build_bot(args.backend)
    if args.demo:
        for query in ["How do I reset my password?", "password recovery", "", "volcano geology"]:
            print(f"\nYou: {query or '(empty)'}\nBot: {reply(engine, query)}")
        return
    print("FAQ assistant. Type exit to stop.")
    while True:
        try:
            query = input("You: ")
        except (EOFError, KeyboardInterrupt):
            break
        if query.strip().casefold() == "exit":
            break
        print("Bot:", reply(engine, query))


if __name__ == "__main__":
    main()
