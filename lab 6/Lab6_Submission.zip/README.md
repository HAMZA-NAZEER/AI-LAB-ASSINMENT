# Lab 6 NLP Fundamentals

This folder contains a runnable notebook and Python files for the three tasks in the supplied Lab 6 manual. The corpus is synthetic teaching data; it is not a real university policy. The notebook runs in Google Colab on CPU and uses the real `sentence-transformers/all-MiniLM-L6-v2` encoder for the semantic comparisons.

## Run in Google Colab

1. Open `Lab6_NLP_Colab.ipynb` in Google Colab.
2. Choose **Runtime > Run all**. The first run installs packages and downloads the encoder model; it may take several minutes.
3. The notebook output shows the tokenizer and chatbot transcripts. The run archive contains `retrieval_log.csv`, `retrieval_metrics.csv`, `selection.json`, and the runnable source/data. A concise record of the Colab outputs is also included as `Colab_Transcript.txt`.

The notebook embeds the source/data files, so it can recreate them in a fresh Colab runtime. Keep the exported `Lab6_Report.docx` with the source files when submitting.

## Local setup

Python 3.10 or newer is recommended.

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python create_dataset.py
python task1_tokens.py --model-tokenizer
python guided_chatbot.py --demo
python task2_chunks.py
python guided_embeddings.py
python guided_suggestions.py
python task3_retrieval.py
python document_chatbot.py --demo
```

`task3_retrieval.py` writes the full top-three evidence log to `retrieval_log.csv`, the six-configuration measurements to `retrieval_metrics.csv`, and the development-only selection to `selection.json`. The CSV includes query, split, score, source ID, source offsets, full chunk text, and whether the labeled evidence is completely present.

## What the tasks compare

- Task 1 compares whitespace tokens, a Unicode word-like regex, and optional MiniLM subword pieces. It also captures exact FAQ behavior, paraphrase suggestions, empty input, and unsupported input.
- Task 2 compares 40-word windows with overlap 0 and 10 against 40-word sentence-aware packing. It records source offsets, repeated text, evidence coverage, a long-sentence fallback, and an abbreviation edge case. Three paraphrased queries are compared with TF-IDF and real sentence embeddings.
- Task 3 uses four answerable development queries, four untouched answerable test queries, and two unanswerable queries. It evaluates all six chunker/backend configurations, reports Hit@3 and MRR@3 separately for development and test, audits encoder token limits, and measures model load separately from encoding and search.

The retrieval scores are ranking signals, not probabilities or evidence of factual correctness. The evidence chatbot shows candidates with source offsets and waits for a person to inspect or decline them. Metadata filtering here is a teaching feature, not access control.

## Data and references

All policy-like passages and questions in the corpus are synthetic. The tokenization examples include public-format text and a short Urdu example written for this exercise. No private data or credentials are included.

The retriever and evaluation pipeline are original instructional implementations adapted to the manual's requirements. Method references:

- Sentence Transformers semantic search: https://www.sbert.net/examples/sentence_transformer/applications/semantic-search/README.html
- `all-MiniLM-L6-v2` model card and input limit: https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2

## Reflection notes

The outputs show that token counts depend on the tokenizer and that fixed word boundaries can split a complete rule. Overlap and sentence packing preserve more complete evidence in the labeled examples, while overlap repeats some words and the simple sentence splitter can mis-handle abbreviations. Embedding scores can retrieve useful paraphrases, but they also return candidates for unanswerable questions. A real help desk needs source-version checks, reviewed data, and a human fallback.

## Tool disclosure

Python, Google Colab, scikit-learn, Sentence Transformers, and AI assistance were used to prepare and review this learning artifact. The author should inspect the outputs and adapt the explanation to their own understanding before submission.

