"""Task 1: compare whitespace, Unicode word-like, and optional model tokens."""

from __future__ import annotations

import argparse
import re

SAMPLES = [
    ("punctuation", "AI, search!"),
    ("contraction", "I can't log in."),
    ("email", "Send help@example.com to support."),
    ("course code", "CS4944 version 2.1"),
    ("empty", ""),
    ("Urdu", "یہ ایک مثال ہے"),
]


def tokens(text: str) -> list[str]:
    return re.findall(r"\b\w+\b", text, flags=re.UNICODE)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-tokenizer", action="store_true", help="Try the optional MiniLM subword tokenizer")
    args = parser.parse_args()
    tokenizer = None
    if args.model_tokenizer:
        try:
            from transformers import AutoTokenizer
            tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
        except Exception as exc:
            print(f"Model tokenizer unavailable; lexical comparison continues ({type(exc).__name__}: {exc})")

    print("Task 1 tokenization comparison")
    for name, text in SAMPLES:
        whitespace = text.split()
        word_like = tokens(text)
        print(f"\n{name}: {text!r}")
        print(f"  whitespace ({len(whitespace)}): {whitespace}")
        print(f"  word-like  ({len(word_like)}): {word_like}")
        if tokenizer is not None and name in {"punctuation", "contraction"}:
            pieces = tokenizer.tokenize(text)
            print(f"  MiniLM subword ({len(pieces)}): {pieces}")
    print("\nInterpretation: whitespace keeps attached punctuation; the regex drops punctuation and splits contractions.")
    print("The Unicode regex can extract Urdu letter sequences, but it is not a complete multilingual tokenizer.")
    print("Normalization can lose punctuation, negation cues, or exact identifiers; retain original text for evidence.")


if __name__ == "__main__":
    main()
