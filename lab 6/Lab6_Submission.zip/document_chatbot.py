"""Interactive evidence search; candidates require confirmation and are never auto-asserted."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from lab6_search import Retriever
from task2_chunks import make_chunks


def build_engine(strategy=None, backend=None):
    docs = json.loads(Path("corpus.json").read_text(encoding="utf-8"))
    selection = json.loads(Path("selection.json").read_text(encoding="utf-8")) if Path("selection.json").exists() else {}
    strategy = strategy or selection.get("strategy", "sentence_40")
    backend = backend or selection.get("backend", "tfidf")
    chunk_strategy = {"window_0": "0", "window_10": "10", "sentence_40": "sentence"}[strategy]
    return Retriever(make_chunks(docs, chunk_strategy), backend), strategy, backend


def format_candidates(engine, query):
    if not query.strip():
        return "Please enter a question."
    hits = engine.search(query, k=3)
    if not hits:
        return "No matching evidence. Rephrase the query or ask a human."
    lines = ["Candidate evidence only; check scope, exceptions, date, and source before using it."]
    for number, (row, score) in enumerate(hits, 1):
        lines.append(f"{number}. {row['id']} score={score:.3f} source={row['source']} chars={row['start']}:{row['end']}")
        lines.append(row["text"])
    lines.append("Choose a candidate to inspect, or press Enter to decline. Similarity is not verification.")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--strategy", choices=["window_0", "window_10", "sentence_40"])
    parser.add_argument("--backend", choices=["tfidf", "embedding"])
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()
    engine, strategy, backend = build_engine(args.strategy, args.backend)
    print(f"Evidence assistant using {strategy}/{backend}")
    if args.demo:
        query = "I was sick; what evidence is needed for an extension?"
        print(f"\nQuestion: {query}\n{format_candidates(engine, query)}")
        print("\nQuestion: What are tomorrow's flight prices?\n" + format_candidates(engine, "What are tomorrow's flight prices?"))
        print("\nQuestion: (empty)\n" + format_candidates(engine, ""))
        return
    while True:
        try:
            query = input("Question (or exit): ")
        except (EOFError, KeyboardInterrupt):
            break
        if query.strip().casefold() == "exit":
            break
        print(format_candidates(engine, query))
        choice = input("Choose 1-3, or press Enter if none apply: ").strip()
        if not choice.isdigit() or not 1 <= int(choice) <= 3:
            print("No answer selected. Rephrase or contact a human.")


if __name__ == "__main__":
    main()
