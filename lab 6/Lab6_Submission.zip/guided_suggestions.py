"""Compare paraphrase suggestions from TF-IDF and the real MiniLM encoder."""

import json
from pathlib import Path

from lab6_search import Retriever
from task2_chunks import make_chunks

docs = json.loads(Path("chunk_docs.json").read_text(encoding="utf-8"))
queries = [
    "I was sick; can I hand it in tomorrow?",
    "My printer is producing empty sheets.",
    "How can I renew an expired API key?",
]
chunks = make_chunks(docs, "sentence")
for backend in ("tfidf", "embedding"):
    print(f"\nBackend: {backend}")
    engine = Retriever(chunks, backend)
    for query in queries:
        print(f"\nQuery: {query}")
        for row, score in engine.search(query, k=3):
            print(row["id"], f"score={score:.3f}", f"chars={row['start']}:{row['end']}", row["text"])
