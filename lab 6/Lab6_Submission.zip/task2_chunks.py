"""Task 2: word-window and sentence-aware chunking with exact source offsets."""

from __future__ import annotations

import json
import re
from pathlib import Path


def word_spans(text: str) -> list[tuple[int, int]]:
    return [(match.start(), match.end()) for match in re.finditer(r"\S+", text)]


def windows(text: str, size: int = 40, overlap: int = 10, offset: int = 0) -> list[tuple[int, int]]:
    if size <= 0 or not 0 <= overlap < size:
        raise ValueError("Require size > 0 and 0 <= overlap < size")
    spans = word_spans(text)
    result = []
    stride = size - overlap
    for start in range(0, len(spans), stride):
        end_index = min(start + size, len(spans))
        result.append((offset + spans[start][0], offset + spans[end_index - 1][1]))
        if end_index == len(spans):
            break
    return result


def sentence_chunks(text: str, size: int = 40, offset: int = 0) -> list[tuple[int, int]]:
    if size <= 0:
        raise ValueError("Require size > 0")
    # Teaching splitter: punctuation followed by whitespace; abbreviations can be split incorrectly.
    cuts = [0] + [match.end() for match in re.finditer(r"[.!?]\s+", text)] + [len(text)]
    spans: list[tuple[int, int]] = []
    pending: tuple[int, int] | None = None
    pending_words = 0
    for start, end in zip(cuts, cuts[1:]):
        segment = text[start:end]
        count = len(segment.split())
        if count == 0:
            continue
        if count > size:
            if pending is not None:
                spans.append(pending)
                pending, pending_words = None, 0
            spans.extend(windows(segment, size=size, overlap=0, offset=start))
        elif pending is not None and pending_words + count <= size:
            pending = (pending[0], end)
            pending_words += count
        else:
            if pending is not None:
                spans.append(pending)
            pending, pending_words = (start, end), count
    if pending is not None:
        spans.append(pending)
    return [(offset + start, offset + end) for start, end in spans]


def make_chunks(docs: dict[str, str], strategy: str) -> list[dict]:
    chunks = []
    for doc_id, text in docs.items():
        spans = sentence_chunks(text) if strategy == "sentence" else windows(text, 40, int(strategy))
        for number, (start, end) in enumerate(spans):
            chunks.append({
                "id": f"{doc_id}:{number}", "doc": doc_id,
                "source": f"synthetic/{doc_id}.txt", "start": start, "end": end,
                "text": text[start:end],
            })
    return chunks


def main() -> None:
    docs_path = Path("chunk_docs.json")
    labels_path = Path("chunk_evidence.json")
    docs = json.loads(docs_path.read_text(encoding="utf-8"))
    evidence = json.loads(labels_path.read_text(encoding="utf-8"))
    strategies = {"window_0": "0", "window_10": "10", "sentence_40": "sentence"}
    all_chunks = {}
    print("Task 2 chunk comparison (40 whitespace words; overlap 0 or 10)")
    for label, strategy in strategies.items():
        chunks = make_chunks(docs, strategy)
        all_chunks[label] = chunks
        print(f"\n{label}: {len(chunks)} total chunks")
        for doc_id, text in docs.items():
            own = [row for row in chunks if row["doc"] == doc_id]
            sizes = [len(row["text"].split()) for row in own]
            repeated = sum(sizes) - len(text.split())
            kept = all(any(item["text"] in row["text"] for row in own) for item in evidence if item["doc"] == doc_id)
            print(f"  {doc_id}: chunks={len(own)}, sizes={sizes}, repeated_words={repeated}, all_evidence_kept={kept}")
            for item in (x for x in evidence if x["doc"] == doc_id):
                preserved = any(item["text"] in row["text"] for row in own)
                print(f"    {item['id']}: complete evidence in one chunk={preserved}")
    # Boundary and metadata checks required by the task.
    assert windows("") == []
    assert windows("short text", size=40, overlap=10) == [(0, 10)]
    try:
        windows("one two", size=2, overlap=2)
    except ValueError:
        print("\nBoundary checks: empty and short inputs passed; invalid overlap rejected.")
    else:
        raise AssertionError("Invalid overlap was accepted")
    long_text = " ".join(["word"] * 95) + "."
    assert all(len(long_text[a:b].split()) <= 40 for a, b in sentence_chunks(long_text))
    assert sentence_chunks("Dr. Smith approved the form. Keep the receipt.", size=40)
    print("Long sentence fallback stayed within 40 words. The simple punctuation splitter can split at abbreviations such as Dr.")
    for chunks in all_chunks.values():
        for row in chunks:
            assert row["text"] == docs[row["doc"]][row["start"]:row["end"]]
    print("All chunk offsets reproduce the exact source substring.")


if __name__ == "__main__":
    main()
