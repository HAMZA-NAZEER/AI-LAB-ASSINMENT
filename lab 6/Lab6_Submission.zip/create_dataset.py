"""Create the expanded, wholly synthetic Lab 6 corpus and relevance labels."""

from __future__ import annotations

import json
from pathlib import Path

LEAD = ("For this synthetic exercise, this document explains the scope of the sample record, describes how to locate evidence, "
        "and distinguishes a general description from a rule that governs a specific situation without treating retrieval as policy.")


def pad_to_words(text: str, target: int, sentence: str) -> str:
    while len(text.split()) < target:
        text += " " + sentence
    words = text.split()
    if len(words) > target:
        text = " ".join(words[:target])
        if not text.endswith((".", "!", "?")):
            text += "."
    return text


def make_doc(evidence1: str, middle: str, evidence2: str, ending: str) -> str:
    # Keep the first required clause at word 36 so window overlap effects are observable.
    lead = LEAD
    if len(lead.split()) != 36:
        raise AssertionError(f"Lead has {len(lead.split())} words, not 36")
    text = f"{lead} {evidence1} {middle} {evidence2} {ending}"
    return pad_to_words(text, 170, ending)


def main():
    docs = {
        "assessment_late": make_doc(
            "Late submissions normally receive a penalty unless an approved extension applies.",
            "The record also describes routine assessment administration, dates, communication channels, and the importance of checking the published version before relying on a summary. These notes provide context rather than extra eligibility rules.",
            "Illness extension requests require medical evidence before the stated deadline.",
            "A student should preserve the complete clause and ask the course office to confirm any unusual case. This synthetic text is only for retrieval practice."),
        "assignment_upload": make_doc(
            "Submit the final assignment as a PDF through the learning portal.",
            "A separate receipt confirms that the uploaded item reached the record. The sample describes ordinary file handling and does not specify real course deadlines, grading rules, or permissions. Use the source identifier to find the full instruction.",
            "A successful upload displays a receipt and submission timestamp.",
            "If a receipt is missing, retain the original file and contact a human support person. The text is synthetic and should not be treated as an actual university rule."),
        "password_reset": make_doc(
            "Use the recovery link on the login page to reset a forgotten password.",
            "Account recovery instructions are separated from unrelated course information so the original evidence can be traced. The sample avoids real credentials and contains no account identifiers. A search result must not expose private codes or imply that a reset has succeeded.",
            "Never share a recovery code with another person or include it in a log.",
            "When the recovery link is unavailable, the intended next step is to contact the help desk. This example is not an authentication system."),
        "contractor_remote": make_doc(
            "Contractors may work remotely only when the signed contract explicitly permits it.",
            "A separate general staff note describes manager-approved remote work for employees. Similar terms can make retrieval confuse one audience with another, so audience labels should be inspected. Metadata filtering in this exercise is a retrieval aid, not access control.",
            "Employees may request remote work with manager approval.",
            "The contractor condition takes precedence for the contractor scenario in this synthetic corpus. Check the source scope and do not infer that employee wording applies to contractors."),
        "printer_blank": make_doc(
            "For blank printer pages, check ink, run the cleaning utility, then print a test page.",
            "A troubleshooting record should preserve the device identity and sequence of steps. The next diagnostic action depends on the model manual. Do not apply scanner instructions to a printer merely because both produce blank output.",
            "Stop if the device reports a hardware warning and consult its manual.",
            "A long diagnostic sentence can exceed a short chunk budget, so the fallback must split it while retaining offsets. This synthetic example does not replace manufacturer guidance."),
        "api_token_v2": make_doc(
            "Renew a version two API token with POST /v2/token/refresh.",
            "Send the refresh_token field and never print its value in logs. A version one document uses a different endpoint, so version metadata matters. Search should preserve the case and punctuation of identifiers and should not call an API during this lab.",
            "The v2 endpoint is POST /v2/token/refresh and expects refresh_token.",
            "A retrieved code reference is evidence to inspect, not proof that a request is valid. Keep source and version labels with every chunk."),
    }
    # Task 2 needs a >40-word sentence to exercise the fallback. Insert it into the printer record.
    long_sentence = ("When a printer has power but produces blank pages, the technician should first confirm that the correct device is selected, "
                     "then check the ink supply, inspect any warning shown on the control panel, run the cleaning utility only when the manual allows it, "
                     "and print a test page so each step can be observed before moving to the next possible cause.")
    docs["printer_blank"] = docs["printer_blank"].replace(
        "A troubleshooting record should preserve the device identity and sequence of steps.",
        long_sentence)
    # Re-pad to 170 after inserting the longer sentence.
    docs["printer_blank"] = pad_to_words(docs["printer_blank"], 170, "The source remains synthetic and identifiable.")
    # A sentence splitter that uses punctuation boundaries can mishandle this abbreviation.
    docs["assessment_late"] += " Dr. Khan reviewed the sample record. This sentence demonstrates an abbreviation boundary."

    questions = [
        {"query": "Is late work penalized?", "doc": "assessment_late", "evidence": "Late submissions normally receive a penalty unless an approved extension applies.", "split": "dev"},
        {"query": "Where should I upload my assignment file?", "doc": "assignment_upload", "evidence": "Submit the final assignment as a PDF through the learning portal.", "split": "dev"},
        {"query": "Where do I reset forgotten credentials?", "doc": "password_reset", "evidence": "Use the recovery link on the login page to reset a forgotten password.", "split": "dev"},
        {"query": "Can a contractor work remotely?", "doc": "contractor_remote", "evidence": "Contractors may work remotely only when the signed contract explicitly permits it.", "split": "dev"},
        {"query": "I was sick; what proof is needed for an extension?", "doc": "assessment_late", "evidence": "Illness extension requests require medical evidence before the stated deadline.", "split": "test"},
        {"query": "My printer is producing empty sheets; what should I do?", "doc": "printer_blank", "evidence": "For blank printer pages, check ink, run the cleaning utility, then print a test page.", "split": "test"},
        {"query": "How can I renew the expired v2 API token?", "doc": "api_token_v2", "evidence": "Renew a version two API token with POST /v2/token/refresh.", "split": "test"},
        {"query": "How can I tell whether the upload succeeded?", "doc": "assignment_upload", "evidence": "A successful upload displays a receipt and submission timestamp.", "split": "test"},
        {"query": "What are tomorrow's flight prices?", "doc": None, "evidence": None, "split": "test"},
        {"query": "Who won the football match?", "doc": None, "evidence": None, "split": "test"},
    ]
    chunk_docs = {key: docs[key] for key in ("assessment_late", "printer_blank", "api_token_v2")}
    chunk_evidence = [
        {"id": "late_rule", "doc": "assessment_late", "text": questions[0]["evidence"]},
        {"id": "illness_exception", "doc": "assessment_late", "text": questions[4]["evidence"]},
        {"id": "printer_steps", "doc": "printer_blank", "text": questions[5]["evidence"]},
        {"id": "api_v2_endpoint", "doc": "api_token_v2", "text": questions[6]["evidence"]},
    ]
    for name, data in [("corpus.json", docs), ("queries.json", questions),
                       ("chunk_docs.json", chunk_docs), ("chunk_evidence.json", chunk_evidence)]:
        Path(name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    for doc_id, text in docs.items():
        count = len(text.split())
        if not 150 <= count <= 250:
            raise AssertionError(f"{doc_id} has {count} words")
    print("Created corpus.json, queries.json, chunk_docs.json, and chunk_evidence.json")
    print("Document word counts:", {key: len(text.split()) for key, text in docs.items()})


if __name__ == "__main__":
    main()
