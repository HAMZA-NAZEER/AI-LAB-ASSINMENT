"""Task 3: evaluate six chunking/backend configurations with source evidence."""

from __future__ import annotations

import csv
import json
import time
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

from task2_chunks import make_chunks

STRATEGIES = {"window_0": "0", "window_10": "10", "sentence_40": "sentence"}


def relevant(row, query):
    return row["doc"] == query["doc"] and query["evidence"] in row["text"]


def metrics(rankings, queries):
    answerable = [i for i, query in enumerate(queries) if query["doc"] is not None]
    hits, rr = [], []
    for i in answerable:
        rank = next((position for position, row in enumerate(rankings[i][:3], 1) if relevant(row[0], queries[i])), None)
        hits.append(rank is not None)
        rr.append(1.0 / rank if rank else 0.0)
    return {"Hit@3": float(np.mean(hits)) if hits else 0.0,
            "MRR@3": float(np.mean(rr)) if rr else 0.0,
            "answerable": len(answerable)}


def rank_scores(scores, chunks, k=3):
    rows = []
    for vector in scores:
        order = np.argsort(-vector, kind="stable")[:k]
        rows.append([(chunks[int(i)], float(vector[int(i)])) for i in order])
    return rows


def main():
    docs = json.loads(Path("corpus.json").read_text(encoding="utf-8"))
    queries = json.loads(Path("queries.json").read_text(encoding="utf-8"))
    texts = [row["query"] for row in queries]
    assert len([q for q in queries if q["doc"] and q["split"] == "dev"]) == 4
    assert len([q for q in queries if q["doc"] and q["split"] == "test"]) == 4
    assert len([q for q in queries if q["doc"] is None]) == 2
    for query in queries:
        if query["doc"] is not None:
            assert query["evidence"] in docs[query["doc"]]

    from sentence_transformers import SentenceTransformer
    t0 = time.perf_counter()
    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2", device="cpu")
    model_load_seconds = time.perf_counter() - t0
    model_limit = int(model.max_seq_length)
    print(f"Model: sentence-transformers/all-MiniLM-L6-v2; device=cpu; max_seq_length={model_limit}")
    print(f"Model load seconds (measured separately): {model_load_seconds:.3f}")

    configs = []
    logs = []
    detail_rankings = {}
    for strategy_name, strategy in STRATEGIES.items():
        chunks = make_chunks(docs, strategy)
        chunk_texts = [row["text"] for row in chunks]
        model_lengths = [len(model.tokenizer(text, truncation=False)["input_ids"]) for text in chunk_texts + texts]
        max_tokens = max(model_lengths, default=0)
        if max_tokens > model_limit:
            raise ValueError(f"{strategy_name}: {max_tokens} model tokens exceeds {model_limit}")
        print(f"\n{strategy_name}: {len(chunks)} chunks; max model tokens={max_tokens}; all within limit")

        # TF-IDF: measure vectorization separately from ranking.
        start = time.perf_counter()
        vectorizer = TfidfVectorizer()
        C = vectorizer.fit_transform(chunk_texts)
        Q = vectorizer.transform(texts)
        encode_seconds = time.perf_counter() - start
        start = time.perf_counter()
        score_matrix = (Q @ C.T).toarray()
        search_seconds = time.perf_counter() - start
        rankings = rank_scores(score_matrix, chunks)
        for split in ("dev", "test"):
            indices = [i for i, q in enumerate(queries) if (q["split"] == split and q["doc"] is not None)]
            m = metrics([rankings[i] for i in indices], [queries[i] for i in indices])
            configs.append({"strategy": strategy_name, "backend": "tfidf", "split": split, **m,
                            "chunks": len(chunks), "encode_seconds": encode_seconds, "search_seconds": search_seconds,
                            "model_load_seconds": model_load_seconds, "max_model_tokens": max_tokens})
        detail_rankings[(strategy_name, "tfidf")] = rankings
        print(f"  TF-IDF vectorization/search seconds: {encode_seconds:.4f}/{search_seconds:.6f}")

        # Real MiniLM sentence embeddings; normalized dot products are cosine similarities.
        start = time.perf_counter()
        vectors = model.encode(chunk_texts + texts, normalize_embeddings=True, convert_to_numpy=True)
        encode_seconds = time.perf_counter() - start
        C_dense, Q_dense = vectors[:len(chunks)], vectors[len(chunks):]
        start = time.perf_counter()
        score_matrix = Q_dense @ C_dense.T
        search_seconds = time.perf_counter() - start
        rankings = rank_scores(score_matrix, chunks)
        for split in ("dev", "test"):
            indices = [i for i, q in enumerate(queries) if (q["split"] == split and q["doc"] is not None)]
            m = metrics([rankings[i] for i in indices], [queries[i] for i in indices])
            configs.append({"strategy": strategy_name, "backend": "embedding", "split": split, **m,
                            "chunks": len(chunks), "encode_seconds": encode_seconds, "search_seconds": search_seconds,
                            "model_load_seconds": model_load_seconds, "max_model_tokens": max_tokens})
        detail_rankings[(strategy_name, "embedding")] = rankings
        print(f"  embedding encode/search seconds: {encode_seconds:.4f}/{search_seconds:.6f}")

        for backend in ("tfidf", "embedding"):
            rows = detail_rankings[(strategy_name, backend)]
            for i, query in enumerate(queries):
                for rank, (chunk, score) in enumerate(rows[i], 1):
                    logs.append({
                        "strategy": strategy_name, "backend": backend, "query": query["query"],
                        "split": query["split"], "answerable": query["doc"] is not None,
                        "expected_doc": query["doc"] or "", "evidence": query["evidence"] or "",
                        "rank": rank, "score": f"{score:.6f}", "doc": chunk["doc"], "chunk_id": chunk["id"],
                        "source": chunk["source"], "start": chunk["start"], "end": chunk["end"],
                        "contains_full_evidence": relevant(chunk, query) if query["doc"] else "",
                        "text": chunk["text"],
                    })

    # Choose once on development metrics; never use held-out scores to select the strategy.
    dev_rows = [row for row in configs if row["split"] == "dev"]
    strategy_priority = {"sentence_40": 0, "window_10": 1, "window_0": 2}
    backend_priority = {"embedding": 0, "tfidf": 1}
    best = sorted(dev_rows, key=lambda row: (-row["Hit@3"], -row["MRR@3"],
                                              strategy_priority[row["strategy"]], backend_priority[row["backend"]]))[0]
    selection = {key: best[key] for key in ("strategy", "backend", "Hit@3", "MRR@3")}
    Path("selection.json").write_text(json.dumps(selection, indent=2), encoding="utf-8")

    with open("retrieval_log.csv", "w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(logs[0]))
        writer.writeheader()
        writer.writerows(logs)
    with open("retrieval_metrics.csv", "w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(configs[0]))
        writer.writeheader()
        writer.writerows(configs)

    print("\nSix-configuration metrics (answerable queries only):")
    for strategy_name in STRATEGIES:
        for backend in ("tfidf", "embedding"):
            dev = next(x for x in configs if x["strategy"] == strategy_name and x["backend"] == backend and x["split"] == "dev")
            test = next(x for x in configs if x["strategy"] == strategy_name and x["backend"] == backend and x["split"] == "test")
            print(f"{strategy_name:12} {backend:9} dev Hit@3={dev['Hit@3']:.3f} MRR@3={dev['MRR@3']:.3f}; "
                  f"test Hit@3={test['Hit@3']:.3f} MRR@3={test['MRR@3']:.3f}; chunks={dev['chunks']}")
    print(f"\nSelected from development only: {selection}")

    chosen = detail_rankings[(best["strategy"], best["backend"])]
    print("\nTop-three evidence for selected configuration (text, IDs, offsets, scores):")
    for query, hits in zip(queries, chosen):
        print(f"\nQUERY [{query['split']}; expected={query['doc'] or 'unanswerable'}]: {query['query']}")
        for rank, (row, score) in enumerate(hits, 1):
            print(f"  {rank}. {row['id']} source={row['source']} chars={row['start']}:{row['end']} score={score:.3f} "
                  f"full_label={relevant(row, query) if query['doc'] else 'not applicable'}")
            print(f"     {row['text']}")

    print("\nFailure and edge-case audit for the selected configuration:")
    misses = []
    for query, hits in zip(queries, chosen):
        if query["doc"] is not None and not any(relevant(row, query) for row, _ in hits):
            misses.append((query, hits))
    for query, hits in misses:
        print(f"MISS: {query['query']} | expected evidence={query['evidence']}")
        print("  retrieved:", [(row["id"], row["start"], row["end"], row["text"]) for row, _ in hits])
    for query, hits in zip(queries, chosen):
        if query["doc"] is None:
            print(f"UNANSWERABLE (candidate ranking is not an answer): {query['query']}")
            print("  returned:", [(row["id"], round(score, 3), row["text"]) for row, score in hits[:2]])
    print("\nSaved retrieval_log.csv, retrieval_metrics.csv, and selection.json")


if __name__ == "__main__":
    main()
