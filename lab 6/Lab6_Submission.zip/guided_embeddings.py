"""Small real-encoder embedding demonstration from the lab manual."""

import numpy as np
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2", device="cpu")
passages = [
    "Reset a forgotten password using the recovery link.",
    "Submit assignments through the learning portal.",
    "Check ink levels when a printer produces blank pages.",
]
C = model.encode(passages, normalize_embeddings=True, convert_to_numpy=True)
Q = model.encode(["How can I recover my login?"], normalize_embeddings=True, convert_to_numpy=True)
scores = (Q @ C.T)[0]
print("Embedding shape:", C.shape)
for i in np.argsort(-scores):
    print(int(i), round(float(scores[i]), 3), passages[int(i)])
print("Maximum norm error:", float(np.max(np.abs(np.linalg.norm(C, axis=1) - 1))))
assert C.shape == (3, 384)
assert np.allclose(np.linalg.norm(C, axis=1), 1, atol=1e-5)
